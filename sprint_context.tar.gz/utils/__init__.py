from __future__ import annotations

from .firestore_client import with_firestore

__all__ = ["with_firestore"]
