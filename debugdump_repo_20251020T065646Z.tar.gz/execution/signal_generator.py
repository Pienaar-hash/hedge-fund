from __future__ import annotations

import importlib
import math
import logging
from collections import OrderedDict, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence
from datetime import datetime

from execution.utils import load_json

_LOG = logging.getLogger("signal_generator")
_STRATEGY_MODULES = ("momentum", "relative_value")
_SEEN_KEYS: "OrderedDict[tuple[str, str, str, str], None]" = OrderedDict()
_LRU_CAPACITY = 1000
_REGISTRY_PATH = Path("config/strategy_registry.json")
_DEFAULT_REG_ENTRY: Dict[str, Any] = {
    "enabled": True,
    "sandbox": False,
    "max_concurrent": 10,
    "confidence": 1.0,
    "capacity_usd": float("inf"),
}


def _load_registry() -> Dict[str, Dict[str, Any]]:
    payload = {}
    try:
        data = load_json(str(_REGISTRY_PATH)) or {}
        if isinstance(data, dict):
            payload = {
                str(k): (dict(v) if isinstance(v, Mapping) else {})
                for k, v in data.items()
            }
    except Exception:
        payload = {}
    # Normalize entries with defaults
    normalized: Dict[str, Dict[str, Any]] = {}
    for key, entry in payload.items():
        normalized_entry = dict(_DEFAULT_REG_ENTRY)
        normalized_entry.update(
            {k: v for k, v in entry.items() if v is not None}
        )
        # Ensure types and sane limits
        normalized_entry["enabled"] = bool(normalized_entry.get("enabled", True))
        normalized_entry["sandbox"] = bool(normalized_entry.get("sandbox", False))
        normalized_entry["max_concurrent"] = max(
            0, int(normalized_entry.get("max_concurrent", 0))
        )
        try:
            normalized_entry["confidence"] = float(normalized_entry.get("confidence", 1.0))
        except Exception:
            normalized_entry["confidence"] = 1.0
        normalized_entry["confidence"] = max(0.0, min(1.5, normalized_entry["confidence"]))
        try:
            cap = float(normalized_entry.get("capacity_usd", float("inf")))
        except Exception:
            cap = float("inf")
        normalized_entry["capacity_usd"] = cap if cap > 0 else float("inf")
        normalized[key] = normalized_entry
    return normalized


def _intent_key(intent: Mapping[str, Any]) -> tuple[str, str, str, str] | None:
    symbol = str(intent.get("symbol") or intent.get("pair") or "").upper()
    if not symbol:
        return None
    tf = str(
        intent.get("timeframe")
        or intent.get("tf")
        or intent.get("interval")
        or ""
    ).lower()
    side = str(intent.get("signal") or intent.get("side") or "").upper()
    candle_close = intent.get("candle_close") or intent.get("timestamp") or intent.get("t")
    if candle_close is None:
        candle_repr = ""
    else:
        try:
            candle_repr = f"{float(candle_close):.4f}"
        except (TypeError, ValueError):
            candle_repr = str(candle_close)
    return (symbol, tf, side, candle_repr)


def _register_key(key: tuple[str, str, str, str]) -> bool:
    if key in _SEEN_KEYS:
        _SEEN_KEYS.move_to_end(key)
        return False
    _SEEN_KEYS[key] = None
    if len(_SEEN_KEYS) > _LRU_CAPACITY:
        _SEEN_KEYS.popitem(last=False)
    return True


def _module_intents(mod: Any, now: float, universe: Sequence[str], cfg: Mapping[str, Any]) -> Iterable[Mapping[str, Any]]:
    gen_fn = getattr(mod, "generate_signals", None)
    if callable(gen_fn):
        try:
            return gen_fn(now=now, universe=universe, config=cfg)
        except TypeError:
            return gen_fn(now, universe, cfg)
    if hasattr(mod, "StrategyImpl"):
        try:
            strat = mod.StrategyImpl()
        except Exception as exc:
            _LOG.debug("StrategyImpl init failed for %s: %s", mod.__name__, exc)
            return []
        prepare = getattr(strat, "prepare", None)
        if callable(prepare):
            try:
                prepare({"now": now, "universe": universe, "config": cfg})
            except Exception as exc:
                _LOG.debug("prepare failed for %s: %s", mod.__name__, exc)
        signals_fn = getattr(strat, "signals", None)
        if callable(signals_fn):
            try:
                return signals_fn(now) or []
            except Exception as exc:
                _LOG.debug("signals failed for %s: %s", mod.__name__, exc)
                return []
    return []


def generate_intents(now: float, universe: Sequence[str] | None = None, cfg: Mapping[str, Any] | None = None) -> List[Mapping[str, Any]]:
    """Load strategy modules and emit deduplicated intents."""
    universe = universe or []
    if cfg is None:
        cfg = load_json("config/strategy_config.json") or {}

    registry = _load_registry()
    emitted: List[Mapping[str, Any]] = []
    per_strategy_counts: Dict[str, int] = defaultdict(int)
    per_strategy_gross: Dict[str, float] = defaultdict(float)

    for name in _STRATEGY_MODULES:
        reg_entry = registry.get(name, dict(_DEFAULT_REG_ENTRY))
        if not reg_entry.get("enabled", True) or reg_entry.get("sandbox", False):
            _LOG.info("strategy %s disabled%s", name, " (sandbox)" if reg_entry.get("sandbox") else "")
            continue
        try:
            mod = importlib.import_module(f"strategies.{name}")
        except ModuleNotFoundError:
            continue
        except Exception as exc:
            _LOG.error("strategy import failed %s: %s", name, exc)
            continue

        try:
            candidates = list(_module_intents(mod, now, universe, cfg))
        except Exception as exc:
            _LOG.error("strategy %s generate failed: %s", name, exc)
            continue

        max_concurrent = reg_entry.get("max_concurrent") or _DEFAULT_REG_ENTRY["max_concurrent"]
        capacity_usd = reg_entry.get("capacity_usd") or _DEFAULT_REG_ENTRY["capacity_usd"]

        for intent in candidates:
            if not isinstance(intent, Mapping):
                continue
            try:
                normalized = normalize_intent(intent)
            except Exception as exc:
                _LOG.debug("intent normalization failed for %s: %s", name, exc)
                continue
            strategy_key = (
                str(
                    normalized.get("strategy")
                    or normalized.get("strategy_name")
                    or normalized.get("strategyId")
                    or name
                )
            )
            entry = registry.get(strategy_key, reg_entry)
            if not entry.get("enabled", True) or entry.get("sandbox", False):
                continue
            max_allowed = entry.get("max_concurrent") or max_concurrent
            if max_allowed and per_strategy_counts[strategy_key] >= max_allowed:
                continue

            # Determine gross sizing for capacity gating
            gross_val = _safe_float(normalized.get("gross_usd"))
            if gross_val <= 0:
                gross_val = 0.0
            cap_usd = entry.get("capacity_usd") or capacity_usd
            if (
                math.isfinite(cap_usd)
                and cap_usd > 0
                and (per_strategy_gross[strategy_key] + gross_val) > cap_usd
            ):
                continue

            confidence = entry.get("confidence", 1.0)
            try:
                confidence = float(confidence)
            except Exception:
                confidence = 1.0
            confidence = max(0.0, min(1.5, confidence))
            normalized["strategy"] = strategy_key
            normalized["confidence"] = confidence
            normalized["signal_strength"] = confidence
            normalized["expected_edge"] = confidence - 0.5
            normalized.setdefault("metadata", {})
            if isinstance(normalized["metadata"], Mapping):
                meta = dict(normalized["metadata"])
                meta.update(
                    {
                        "registry_confidence": confidence,
                        "registry_capacity": cap_usd,
                        "registry_max_concurrent": max_allowed,
                    }
                )
                normalized["metadata"] = meta
            key = _intent_key(normalized)
            if key is None:
                continue
            if not _register_key(key):
                continue
            per_strategy_counts[strategy_key] += 1
            per_strategy_gross[strategy_key] += gross_val
            emitted.append(normalized)

    return emitted


def generate_signals(
    now: float,
    universe: Sequence[str] | None = None,
    cfg: Mapping[str, Any] | None = None,
) -> List[Mapping[str, Any]]:
    return generate_intents(now, universe, cfg)


def _safe_float(value: Any) -> float:
    try:
        return float(value)
    except Exception:
        return 0.0


def _normalize_timestamp(raw: Any) -> str:
    if raw in (None, ""):
        return datetime.utcnow().isoformat()
    if isinstance(raw, (int, float)):
        try:
            return datetime.utcfromtimestamp(float(raw)).isoformat()
        except Exception:
            return datetime.utcnow().isoformat()
    return str(raw)


def normalize_intent(intent: Mapping[str, Any]) -> Dict[str, Any]:
    normalized: Dict[str, Any] = dict(intent)
    symbol = normalized.get("symbol") or normalized.get("pair")
    symbol_str = str(symbol or "").upper()
    if not symbol_str:
        raise ValueError("intent missing symbol")
    normalized["symbol"] = symbol_str

    normalized["timestamp"] = _normalize_timestamp(
        normalized.get("timestamp") or normalized.get("ts") or normalized.get("time")
    )

    tf = (
        normalized.get("timeframe")
        or normalized.get("tf")
        or normalized.get("interval")
        or normalized.get("time_frame")
    )
    tf_str = str(tf or "unknown").lower()
    normalized["timeframe"] = tf_str
    normalized["tf"] = tf_str

    signal = normalized.get("signal") or normalized.get("side")
    normalized["signal"] = str(signal or "").upper()

    normalize_reduce = normalized.get("reduceOnly", normalized.get("reduce_only"))
    normalized["reduceOnly"] = bool(normalize_reduce)

    normalized["price"] = _safe_float(normalized.get("price"))
    normalized["capital_per_trade"] = _safe_float(
        normalized.get("capital_per_trade") or normalized.get("capital") or normalized.get("notional")
    )
    lev_value = (
        normalized.get("leverage")
        or normalized.get("lev")
        or normalized.get("leverage_target")
    )
    lev_float = _safe_float(lev_value)
    normalized["leverage"] = lev_float if lev_float > 0 else 1.0

    gross_value = normalized.get("gross_usd")
    if gross_value in (None, ""):
        normalized["gross_usd"] = abs(normalized["capital_per_trade"]) * max(normalized["leverage"], 1.0)
    else:
        normalized["gross_usd"] = abs(_safe_float(gross_value))

    pos_side = normalized.get("positionSide") or normalized.get("posSide") or normalized.get("side")
    normalized["positionSide"] = str(pos_side or "")

    veto_raw = normalized.get("veto")
    if isinstance(veto_raw, str):
        veto_list = [veto_raw]
    elif isinstance(veto_raw, Mapping):
        veto_list = [str(item) for item in veto_raw.values() if item]
    elif isinstance(veto_raw, Iterable) and not isinstance(veto_raw, (str, bytes)):
        veto_list = [str(item) for item in veto_raw if item]
    elif veto_raw:
        veto_list = [str(veto_raw)]
    else:
        veto_list = []
    normalized["veto"] = veto_list

    return normalized


__all__ = ["generate_intents", "generate_signals", "normalize_intent"]
