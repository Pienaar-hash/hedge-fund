"""Developer alias for the Streamlit dashboard."""

from dashboard.app import main


if __name__ == "__main__":
    main()
